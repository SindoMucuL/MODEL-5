<?php
declare(strict_types=1);
require_once __DIR__ . '/Mahasiswa.php';

class DataMahasiswa {
    /** @var array<string, Mahasiswa> kunci array = NIM */
    private array $data = [];

    public function __construct(array $dataAwal = []) {
        foreach ($dataAwal as $item) {
            if ($item instanceof Mahasiswa) {
                $this->data[$item->getNim()] = $item;
            }
        }
    }

    public function tambah(Mahasiswa $m): bool {
        if (isset($this->data[$m->getNim()])) return false; // NIM duplikat ditolak
        $this->data[$m->getNim()] = $m;
        return true;
    }

    /** @return array<string, Mahasiswa> */
    public function semua(): array { return $this->data; }

    public function cari(string $nim): ?Mahasiswa {
        return $this->data[$nim] ?? null;
    }

    // NIM tetap: perubahan NIM ditolak agar kunci repository tetap konsisten.
    public function ubah(string $nimLama, Mahasiswa $m): bool {
        if (!isset($this->data[$nimLama])) return false;
        if ($m->getNim() !== $nimLama) return false;
        $this->data[$nimLama] = $m;
        return true;
    }

    public function hapus(string $nim): bool {
        if (!isset($this->data[$nim])) return false;
        unset($this->data[$nim]);
        return true;
    }
}
