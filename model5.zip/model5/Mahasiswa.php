<?php
declare(strict_types=1);

/**
 * Pertemuan 5 - Enkapsulasi.
 * Semua property private. Akses dari luar hanya lewat getter/setter.
 * NIM adalah identitas tetap: hanya punya getter, tidak ada setNim().
 */
class Mahasiswa {
    public const AGAMA = ['Islam', 'Kristen', 'Katolik', 'Hindu', 'Buddha', 'Konghucu'];
    public const GOLONGAN_DARAH = ['A', 'B', 'AB', 'O'];

    private string $nim;
    private string $nama;
    private string $fakultas;
    private string $prodi;
    private string $asalSekolah;
    private int $semester;
    private string $hobi;
    private string $agama;
    private string $alamat;
    private string $golonganDarah;

    // Constructor memanggil setter agar aturan validasi hanya ditulis satu kali.
    public function __construct(
        string $nim,
        string $nama,
        string $fakultas,
        string $prodi,
        string $asalSekolah,
        int $semester,
        string $hobi,
        string $agama,
        string $alamat,
        string $golonganDarah
    ) {
        $this->nim = self::wajib($nim, 'NIM');
        $this->setNama($nama);
        $this->setFakultas($fakultas);
        $this->setProdi($prodi);
        $this->setAsalSekolah($asalSekolah);
        $this->setSemester($semester);
        $this->setHobi($hobi);
        $this->setAgama($agama);
        $this->setAlamat($alamat);
        $this->setGolonganDarah($golonganDarah);
    }

    // Pemeriksa bersama: buang spasi tepi, tolak nilai kosong.
    private static function wajib(string $nilai, string $label): string {
        $nilai = trim($nilai);
        if ($nilai === '') {
            throw new InvalidArgumentException($label . ' wajib diisi.');
        }
        return $nilai;
    }

    // ---------- Getter ----------
    public function getNim(): string { return $this->nim; }
    public function getNama(): string { return $this->nama; }
    public function getFakultas(): string { return $this->fakultas; }
    public function getProdi(): string { return $this->prodi; }
    public function getAsalSekolah(): string { return $this->asalSekolah; }
    public function getSemester(): int { return $this->semester; }
    public function getHobi(): string { return $this->hobi; }
    public function getAgama(): string { return $this->agama; }
    public function getAlamat(): string { return $this->alamat; }
    public function getGolonganDarah(): string { return $this->golonganDarah; }

    // ---------- Setter (gerbang validasi) ----------
    public function setNama(string $nama): void {
        $this->nama = self::wajib($nama, 'Nama');
    }
    public function setFakultas(string $fakultas): void {
        $this->fakultas = self::wajib($fakultas, 'Fakultas');
    }
    public function setProdi(string $prodi): void {
        $this->prodi = self::wajib($prodi, 'Program Studi');
    }
    public function setAsalSekolah(string $asalSekolah): void {
        $this->asalSekolah = self::wajib($asalSekolah, 'Asal Sekolah');
    }
    public function setSemester(int $semester): void {
        if ($semester < 1 || $semester > 14) {
            throw new InvalidArgumentException('Semester harus 1–14.');
        }
        $this->semester = $semester;
    }
    public function setHobi(string $hobi): void {
        $this->hobi = trim($hobi); // hobi boleh kosong
    }
    public function setAgama(string $agama): void {
        if (!in_array($agama, self::AGAMA, true)) {
            throw new InvalidArgumentException('Pilihan agama tidak valid.');
        }
        $this->agama = $agama;
    }
    public function setAlamat(string $alamat): void {
        $this->alamat = self::wajib($alamat, 'Alamat');
    }
    public function setGolonganDarah(string $golonganDarah): void {
        $nilai = strtoupper(self::wajib($golonganDarah, 'Golongan darah'));
        if (!in_array($nilai, self::GOLONGAN_DARAH, true)) {
            throw new InvalidArgumentException('Golongan darah harus A, B, AB, atau O.');
        }
        $this->golonganDarah = $nilai;
    }

    public function ringkasan(): string {
        return $this->nim . ' - ' . $this->nama;
    }
}
