<?php
declare(strict_types=1);
require_once __DIR__ . '/DataMahasiswa.php';

function aman(mixed $teks): string {
    return htmlspecialchars((string)$teks, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

// Membuat Mahasiswa valid; parameter bisa ditimpa untuk menguji input tidak valid.
function buat(array $o = []): Mahasiswa {
    $d = array_merge([
        'nim' => '2530521030', 'nama' => 'Muhammad Fadhil Sakhi', 'fakultas' => 'Sains dan Teknologi',
        'prodi' => 'Teknik Informatika', 'asal' => 'SMAN 1', 'semester' => 4, 'hobi' => 'Coding',
        'agama' => 'Islam', 'alamat' => 'Sukabumi', 'darah' => 'O',
    ], $o);
    return new Mahasiswa($d['nim'], $d['nama'], $d['fakultas'], $d['prodi'], $d['asal'],
        $d['semester'], $d['hobi'], $d['agama'], $d['alamat'], $d['darah']);
}

// Menjalankan satu uji. Hasil: [keluaran sebenarnya, lulus?]
function uji(callable $aksi, string $harapan): array {
    try {
        $hasil = (string)$aksi();
    } catch (Throwable $e) {
        $hasil = get_class($e) . ': ' . $e->getMessage();
    }
    return [$hasil, str_contains($hasil, $harapan)];
}

$tes = [];

$tes[] = ['01', 'Mahasiswa valid, semester 4', 'Objek dibuat dan tersimpan', 'OK: ', function () {
    $repo = new DataMahasiswa();
    $m = buat();
    return $repo->tambah($m) ? 'OK: ' . $m->ringkasan() . ', semester ' . $m->getSemester() : 'GAGAL';
}];
$tes[] = ['02', 'NIM kosong', 'Ditolak: NIM wajib diisi.', 'NIM wajib diisi.', fn() => buat(['nim' => '   '])];
$tes[] = ['03', 'Semester -1', 'Ditolak setter: Semester harus 1–14.', 'Semester harus 1–14.', fn() => buat(['semester' => -1])];
$tes[] = ['04', 'Semester 15', 'Ditolak setter: Semester harus 1–14.', 'Semester harus 1–14.', fn() => buat(['semester' => 15])];
$tes[] = ['05', 'Nama kosong/spasi', 'Ditolak setter: Nama wajib diisi.', 'Nama wajib diisi.', fn() => buat(['nama' => '   '])];
$tes[] = ['06', 'Akses langsung $m->semester', 'Error akses private', 'Cannot access private property', function () {
    $m = buat();
    return $m->semester; // sengaja salah: property private
}];
$tes[] = ['06b', 'Ubah langsung $m->semester = -7', 'Error akses private', 'Cannot access private property', function () {
    $m = buat();
    $m->semester = -7; // sengaja salah: property private
    return $m->getSemester();
}];
$tes[] = ['07', 'Edit nama valid (lewat setNama)', 'Data berubah melalui jalur yang diizinkan', 'Nama baru: Siti', function () {
    $repo = new DataMahasiswa();
    $repo->tambah(buat());
    $m = $repo->cari('2530521030');
    $m->setNama('  Siti  ');
    return 'Nama baru: ' . $repo->cari('2530521030')->getNama();
}];
$tes[] = ['07b', 'Edit semester 20 (lewat setSemester)', 'Ditolak setter', 'Semester harus 1–14.', function () {
    $m = buat();
    $m->setSemester(20);
    return 'berubah';
}];
$tes[] = ['08', 'NIM duplikat pada tambah', 'Ditolak oleh repository', 'Hasil tambah ke-2: DITOLAK', function () {
    $repo = new DataMahasiswa();
    $repo->tambah(buat());
    return 'Hasil tambah ke-2: ' . ($repo->tambah(buat(['nama' => 'Orang Lain'])) ? 'DITERIMA' : 'DITOLAK');
}];
$tes[] = ['08b', 'Ubah dengan NIM berbeda', 'Ditolak oleh repository', 'Hasil ubah: DITOLAK', function () {
    $repo = new DataMahasiswa();
    $repo->tambah(buat());
    return 'Hasil ubah: ' . ($repo->ubah('2530521030', buat(['nim' => '999'])) ? 'DITERIMA' : 'DITOLAK');
}];
$tes[] = ['09', 'Hapus satu mahasiswa', 'Hanya record terkait dihapus', 'Sisa data: 1 (2530521031)', function () {
    $repo = new DataMahasiswa();
    $repo->tambah(buat());
    $repo->tambah(buat(['nim' => '2530521031']));
    $repo->hapus('2530521030');
    return 'Sisa data: ' . count($repo->semua()) . ' (' . implode(', ', array_keys($repo->semua())) . ')';
}];
// Kasus 10 (refresh browser) diuji manual di index.php; ini kasus tambahan.
$tes[] = ['11', 'Agama & golongan darah tidak valid', 'Ditolak setter', 'Pilihan agama tidak valid. | Golongan darah harus A, B, AB, atau O.', function () {
    try { buat(['agama' => 'Lainnya']); } catch (InvalidArgumentException $e) { $a = $e->getMessage(); }
    try { buat(['darah' => 'Z']); } catch (InvalidArgumentException $e) { $b = $e->getMessage(); }
    return ($a ?? 'DITERIMA') . ' | ' . ($b ?? 'DITERIMA');
}];

$baris = [];
foreach ($tes as [$no, $skenario, $harapan, $kunci, $aksi]) {
    // Lulus jika keluaran memuat teks kunci yang diharapkan.
    [$hasil, $lulus] = uji($aksi, $kunci);
    $baris[] = [$no, $skenario, $harapan, $hasil, $lulus];
}
$lulusSemua = count(array_filter($baris, fn($b) => $b[4]));
?>
<!doctype html>
<html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Pengujian Enkapsulasi - Mahasiswa</title>
<style>
    body{font-family:system-ui,Arial,sans-serif;background:#f1f5f9;color:#15324d;margin:0}
    main{max-width:1120px;margin:36px auto;padding:0 18px}
    .panel{background:#fff;border-radius:13px;padding:24px;margin:20px 0;box-shadow:0 5px 18px #16324d14}
    table{border-collapse:collapse;width:100%;font-size:13px}
    th,td{padding:10px 9px;text-align:left;border-bottom:1px solid #e1e8f0;vertical-align:top}
    th{background:#e8f1f8}.ok{color:#1b7a3d;font-weight:700}.no{color:#b9414a;font-weight:700}
    code{background:#eef3f8;padding:1px 5px;border-radius:4px}
    .scroll{overflow-x:auto}
</style></head>
<body><main>
<h1>Pengujian Enkapsulasi</h1>
<p>Class <code>Mahasiswa</code> dan <code>DataMahasiswa</code> diuji langsung tanpa form. Lulus: <b><?= $lulusSemua ?>/<?= count($baris) ?></b></p>
<section class="panel"><div class="scroll"><table>
<thead><tr><th>No.</th><th>Skenario</th><th>Harapan</th><th>Keluaran sebenarnya</th><th>Status</th></tr></thead>
<tbody>
<?php foreach ($baris as [$no, $skenario, $harapan, $hasil, $lulus]): ?>
<tr>
    <td><?= aman($no) ?></td>
    <td><?= aman($skenario) ?></td>
    <td><?= aman($harapan) ?></td>
    <td><?= aman($hasil) ?></td>
    <td class="<?= $lulus ? 'ok' : 'no' ?>"><?= $lulus ? 'Sesuai' : 'Tidak' ?></td>
</tr>
<?php endforeach; ?>
</tbody></table></div></section>
<p><a href="index.php">← Kembali ke CRUD</a></p>
</main></body></html>
