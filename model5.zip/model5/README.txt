PBO PERTEMUAN 5 - ENKAPSULASI (PHP 8+ / XAMPP)

1. Salin folder ini ke C:\xampp\htdocs\pbo05-enkapsulasi
2. Jalankan Apache di XAMPP Control Panel.
3. Buka http://localhost/pbo05-enkapsulasi/index.php

BERKAS
Mahasiswa.php        class entity: property private, getter, setter + validasi
DataMahasiswa.php    repository CRUD (memakai getNim(), menolak perubahan NIM)
index.php            form, controller, session, tabel (memakai getter)
contoh1.php - contoh5.php   percobaan C.1 - C.5 di laporan
tugas1_produk.php    Tugas 1: public / protected / private
tugas2_buku.php      Tugas 2: class Buku (2 input valid, 3 tidak valid)
uji_enkapsulasi.php  skenario uji 01-10 untuk class Mahasiswa

PERUBAHAN DARI PERTEMUAN 4
- Semua property Mahasiswa menjadi private; akses lewat getter/setter.
- __get/__set/__isset/__unset/__call/__destruct dihapus dari Mahasiswa.
- NIM tidak punya setter; pada Edit kolom NIM read-only dan repository menolak
  perubahan NIM.
- Bug P4 diperbaiki: parameter email yang tidak dipakai dihapus (membuat tambah
  data gagal), typo ',agama' pada validasi, label "Golongandarah" -> "Golongan Darah",
  colspan tabel.
- Session lama (P4) dikosongkan otomatis sekali (kunci 'versi').

CATATAN
- contoh1.php sengaja menghasilkan -7 (membuktikan bahaya property public).
- Hapus/ganti file demo_konsep.php, constructor.php, Destructor.php,
  overloading_property.php milik Pertemuan 4: tidak dipakai di folder ini.
- Data tersimpan di PHP Session (sementara), bukan database.
